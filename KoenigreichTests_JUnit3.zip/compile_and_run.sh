#!/bin/sh
set -eu
export CLASSPATH="bin:../lib/junit3.8.2/junit.jar"
javac -d ./bin koenigreich/*.java tests/*.java
java tests.AlleTestsKoenigreich
rm -rf ./bin
