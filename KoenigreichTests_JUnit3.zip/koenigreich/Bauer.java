package koenigreich;

public class Bauer extends Einwohner {

}
