package koenigreich;

public class Koenig extends Einwohner {
    public int steuer() {
        // Vorschrift (3)
        return 0;
    }
}
